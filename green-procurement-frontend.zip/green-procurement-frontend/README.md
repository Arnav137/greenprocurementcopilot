# Green Procurement Copilot: Frontend
    cp .env.example .env     # VITE_USE_MOCK=true works with no backend
    npm install
    npm run dev              # http://localhost:5173
Set VITE_USE_MOCK=false and VITE_API_URL to use the real FastAPI backend (restart `npm run dev` after editing .env).
