// ALL backend calls live here. Components never call fetch directly.
import * as mock from "../mocks/data.js";

const USE_MOCK = import.meta.env.VITE_USE_MOCK === "true";
const API = import.meta.env.VITE_API_URL || "http://localhost:8000";
const wait = (ms = 300) => new Promise((r) => setTimeout(r, ms));

async function http(path, options) {
  const res = await fetch(`${API}${path}`, options);
  if (!res.ok) throw new Error(`${path} failed (${res.status})`);
  return res.json();
}
const json = (method, body) => ({ method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });

export const reportUrl = () => `${API}/report`;

export async function uploadFile(file) {
  if (USE_MOCK) { await wait(800); return { status: "ok", lines_found: mock.lines.length }; }
  const form = new FormData(); // do NOT set Content-Type; the browser adds the boundary
  form.append("file", file);
  return http("/upload", { method: "POST", body: form });
}
export async function getLines() {
  if (USE_MOCK) { await wait(); return structuredClone(mock.lines); }
  return http("/lines");
}
export async function patchLine(id, changes) {
  if (USE_MOCK) { await wait(150); return { id, ...changes }; }
  return http(`/lines/${id}`, json("PATCH", changes));
}
export async function getHotspots() {
  if (USE_MOCK) { await wait(); return mock.hotspots; }
  return http("/hotspots");
}
export async function getSuppliers(lineId) {
  if (USE_MOCK) { await wait(); return mock.suppliers; }
  return http(`/suppliers/${lineId}`);
}
export async function runScenario({ line_id, supplier_id, shift_pct }) {
  if (USE_MOCK) { // mock only: the real calculation is done by the backend
    await wait(150);
    const c = mock.suppliers.current;
    const o = mock.suppliers.options.find((x) => x.id === supplier_id) || mock.suppliers.options[0];
    const f = shift_pct / 100;
    const mix = (a, b) => a + f * (b - a);
    return {
      baseline: { cost: c.total_cost, kg_co2e: c.kg_co2e, lead_time_days: c.lead_time_days },
      scenario: { cost: mix(c.total_cost, o.total_cost), kg_co2e: mix(c.kg_co2e, o.kg_co2e), lead_time_days: Math.max(c.lead_time_days, f > 0 ? o.lead_time_days : 0) },
      assumptions: ["Linear mix of current and alternative supplier", "Demo data"],
    };
  }
  return http("/scenario", json("POST", { line_id, supplier_id, shift_pct }));
}
export async function getRecommendation(lineId) {
  if (USE_MOCK) { await wait(); return mock.recommendation; }
  return http(`/recommendation/${lineId}`);
}
export async function approve({ line_id, decision, note }) {
  if (USE_MOCK) { await wait(); return { status: decision, decided_at: new Date().toISOString() }; }
  return http("/approve", json("POST", { line_id, decision, note }));
}
