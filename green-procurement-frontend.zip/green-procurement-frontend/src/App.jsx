import { NavLink, Navigate, Route, Routes } from "react-router-dom";
import UploadPage from "./pages/UploadPage.jsx";
import ReviewPage from "./pages/ReviewPage.jsx";
import DashboardPage from "./pages/DashboardPage.jsx";
import ComparePage from "./pages/ComparePage.jsx";
import ApprovalPage from "./pages/ApprovalPage.jsx";

const nav = [["/upload", "Upload"], ["/review", "Review"], ["/dashboard", "Hotspots"], ["/compare/1", "Compare"], ["/approve/1", "Approve"]];

export default function App() {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-emerald-900 text-white">
        <div className="max-w-6xl mx-auto px-4 py-3 flex flex-wrap items-center gap-6">
          <span className="font-semibold">Green Procurement Copilot</span>
          <nav className="flex gap-4 text-sm">
            {nav.map(([to, label]) => (
              <NavLink key={to} to={to} className={({ isActive }) => (isActive ? "underline" : "opacity-80 hover:opacity-100")}>{label}</NavLink>
            ))}
          </nav>
        </div>
      </header>
      <main className="max-w-6xl mx-auto w-full px-4 py-6 flex-1">
        <Routes>
          <Route path="/" element={<Navigate to="/upload" replace />} />
          <Route path="/upload" element={<UploadPage />} />
          <Route path="/review" element={<ReviewPage />} />
          <Route path="/dashboard" element={<DashboardPage />} />
          <Route path="/compare/:lineId" element={<ComparePage />} />
          <Route path="/approve/:lineId" element={<ApprovalPage />} />
        </Routes>
      </main>
      <footer className="text-xs text-stone-500 text-center py-4">
        Demo data. Values are estimates, not a certified carbon footprint.
      </footer>
    </div>
  );
}
