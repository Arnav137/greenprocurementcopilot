import { useEffect, useState } from "react";

// Runs an async function, tracks loading/error/data. retry() re-runs it.
export function useAsync(fn, deps = []) {
  const [s, setS] = useState({ data: null, loading: true, error: null });
  const [n, setN] = useState(0);
  useEffect(() => {
    let live = true;
    setS((p) => ({ ...p, loading: true, error: null }));
    fn().then((data) => live && setS({ data, loading: false, error: null }))
        .catch((e) => live && setS({ data: null, loading: false, error: e.message }));
    return () => { live = false; };
  }, [...deps, n]);
  return { ...s, retry: () => setN((x) => x + 1) };
}

const tones = {
  green: "bg-emerald-100 text-emerald-800", blue: "bg-sky-100 text-sky-800",
  amber: "bg-amber-100 text-amber-800", red: "bg-red-100 text-red-800", gray: "bg-stone-200 text-stone-700",
};
export const QUALITY_TONE = { verified: "green", reported: "blue", estimated: "amber", unknown: "gray" };

export const Badge = ({ children, tone = "gray" }) => (
  <span className={`inline-block rounded px-2 py-0.5 text-xs font-medium ${tones[tone]}`}>{children}</span>
);
export const QualityBadge = ({ q }) => <Badge tone={QUALITY_TONE[q] || "gray"}>{q || "unknown"}</Badge>;

export const Spinner = ({ label = "Loading…" }) => (
  <div className="flex items-center gap-2 text-stone-600 py-8"><div className="h-4 w-4 rounded-full border-2 border-emerald-700 border-t-transparent animate-spin" />{label}</div>
);
export const ErrorBox = ({ message, onRetry }) => (
  <div className="rounded border border-red-300 bg-red-50 p-4 text-red-800">
    <p>{message}</p>
    {onRetry && <button onClick={onRetry} className="mt-2 underline">Try again</button>}
  </div>
);
export const Empty = ({ children }) => <div className="rounded border border-dashed p-8 text-center text-stone-500">{children}</div>;
export const Title = ({ children, sub }) => (
  <div className="mb-4"><h1 className="text-2xl font-semibold">{children}</h1>{sub && <p className="text-stone-600 text-sm mt-1">{sub}</p>}</div>
);
export const StatCard = ({ label, value, sub, tone }) => (
  <div className="rounded border bg-white p-4">
    <div className="text-xs text-stone-500">{label}</div>
    <div className={`text-xl font-semibold ${tone || ""}`}>{value}</div>
    {sub && <div className="text-xs text-stone-500 mt-1">{sub}</div>}
  </div>
);
// Never show a bare number: null becomes "Unavailable", never 0.
export const inr = (n) => (n == null ? "Unavailable" : "₹" + Math.round(n).toLocaleString("en-IN"));
export const kg = (n) => (n == null ? "Unavailable" : Math.round(n).toLocaleString("en-IN") + " kg CO₂e");
export const Card = ({ title, children }) => (
  <section className="rounded border bg-white p-4">{title && <h2 className="font-medium mb-2">{title}</h2>}{children}</section>
);
export const BulletList = ({ items }) => (
  <ul className="list-disc pl-5 space-y-1 text-sm">{items.map((x, i) => <li key={i}>{x}</li>)}</ul>
);
