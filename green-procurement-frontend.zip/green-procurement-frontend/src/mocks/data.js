// Fake data matching the team's API contract. Update when the schema changes.
export const lines = [
  { id: 1, supplier: "PackWell Ltd", item: "Corrugated box 40x30x20", quantity: 5000, unit: "pcs", unit_price: 42, total_price: 210000, currency: "INR", category: "Corrugated packaging", confidence: 0.95, uncertain_fields: [], source: "invoice_1.pdf p1 l1" },
  { id: 2, supplier: "PackWell Ltd", item: "Bubble wrap roll 100m", quantity: 120, unit: "roll", unit_price: 650, total_price: 78000, currency: "INR", category: "Plastic packaging", confidence: 0.7, uncertain_fields: ["unit"], source: "invoice_1.pdf p1 l2" },
  { id: 3, supplier: "Shree Papers", item: "Kraft paper sheets", quantity: 800, unit: "kg", unit_price: 70, total_price: 56000, currency: "INR", category: "Paper packaging", confidence: 0.88, uncertain_fields: [], source: "invoice_2.pdf p1 l1" },
  { id: 4, supplier: "Shree Papers", item: "Custom insert (unspecified)", quantity: 300, unit: "pcs", unit_price: 95, total_price: 28500, currency: "INR", category: "Unknown", confidence: 0.4, uncertain_fields: ["category", "unit"], source: "invoice_2.pdf p2 l3" },
];
export const hotspots = [
  { line_id: 1, category: "Corrugated packaging", item: "Corrugated box", kg_co2e: 4200, method: "activity-based", quality: "estimated", factor_source: "Demo factor (verify source), 2026, kg CO2e/kg" },
  { line_id: 2, category: "Plastic packaging", item: "Bubble wrap", kg_co2e: 2600, method: "spend-based", quality: "estimated", factor_source: "Demo spend factor, 2026" },
  { line_id: 3, category: "Paper packaging", item: "Kraft paper", kg_co2e: 1100, method: "activity-based", quality: "reported", factor_source: "Supplier-reported" },
  { line_id: 4, category: "Unknown", item: "Custom insert", kg_co2e: null, method: null, quality: "unknown", factor_source: "No compatible factor" },
];
export const suppliers = {
  current: { name: "PackWell Ltd", unit_price: 42, total_cost: 210000, kg_co2e: 4200, lead_time_days: 7, evidence_quality: "estimated" },
  options: [
    { id: "s2", name: "EcoBox Industries", eligible: true, unit_price: 46, total_cost: 230000, kg_co2e: 2900, lead_time_days: 9, evidence_quality: "reported", method: "supplier-specific" },
    { id: "s3", name: "GreenPack Co", eligible: true, unit_price: 44, total_cost: 220000, kg_co2e: 3400, lead_time_days: 8, evidence_quality: "verified", method: "activity-based" },
    { id: "s4", name: "FarEast Cartons", eligible: false, reject_reason: "Lead time 21 days exceeds the 14-day limit", unit_price: 36, total_cost: 180000, kg_co2e: 2500, lead_time_days: 21, evidence_quality: "unknown", method: "spend-based" },
  ],
  missing_data: ["EcoBox: recycled content not provided", "Box weight per unit not on invoice"],
};
export const recommendation = {
  summary: "Move 60% of corrugated box volume to GreenPack Co.",
  evidence: ["GreenPack emissions are verified (third-party certificate, 2025)", "Cost increase is about 4.8% at 100% shift", "Lead time stays inside the 14-day limit"],
  assumptions: ["Weight per box assumed 0.35 kg (not on invoice)", "Factor geography: demo data"],
  risks: ["Single new supplier for 60% of volume", "Certificate expires 2027"],
  missing_data: suppliers.missing_data,
  questions: ["Can you confirm recycled content for this box spec?", "What is your capacity for 3,000 boxes/month?"],
};
