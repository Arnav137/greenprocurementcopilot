import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { getSuppliers, runScenario } from "../api/client.js";
import { Badge, BulletList, Card, ErrorBox, QualityBadge, Spinner, StatCard, Title, inr, kg, useAsync } from "../components/ui.jsx";

const STEPS = [0, 20, 40, 60, 100];

export default function ComparePage() {
  const { lineId } = useParams();
  const { data, loading, error, retry } = useAsync(() => getSuppliers(lineId), [lineId]);
  const [supplierId, setSupplierId] = useState(null);
  const [pct, setPct] = useState(60);
  const [result, setResult] = useState(null);
  const [scnErr, setScnErr] = useState(null);

  useEffect(() => { // default to first eligible supplier
    if (data && !supplierId) setSupplierId(data.options.find((o) => o.eligible)?.id ?? null);
  }, [data]);

  useEffect(() => { // debounced: wait 300ms after the last change before calling the backend
    if (!supplierId) return;
    const t = setTimeout(() => {
      runScenario({ line_id: Number(lineId), supplier_id: supplierId, shift_pct: pct })
        .then((r) => { setResult(r); setScnErr(null); }).catch((e) => setScnErr(e.message));
    }, 300);
    return () => clearTimeout(t);
  }, [lineId, supplierId, pct]);

  if (loading) return <Spinner />;
  if (error) return <ErrorBox message={error} onRetry={retry} />;
  const { current, options, missing_data } = data;
  const delta = (a, b) => (b == null || a == null ? null : b - a);
  const tone = (d) => (d == null || d === 0 ? "" : d < 0 ? "text-emerald-700" : "text-red-700"); // lower is better

  return (
    <div className="space-y-4">
      <Title sub="Mandatory constraints are applied first. Rejected suppliers stay visible with the reason.">Supplier comparison</Title>
      <div className="overflow-x-auto rounded border bg-white">
        <table className="w-full text-sm">
          <thead className="bg-stone-100 text-left"><tr>{["", "Supplier", "Cost", "CO₂e", "Lead time", "Evidence", "Status"].map((h) => <th key={h} className="p-2 font-medium">{h}</th>)}</tr></thead>
          <tbody>
            <tr className="border-t bg-stone-50"><td className="p-2" /><td className="p-2 font-medium">{current.name} (current)</td><td className="p-2">{inr(current.total_cost)}</td><td className="p-2">{kg(current.kg_co2e)}</td><td className="p-2">{current.lead_time_days} d</td><td className="p-2"><QualityBadge q={current.evidence_quality} /></td><td className="p-2"><Badge>baseline</Badge></td></tr>
            {options.map((o) => (
              <tr key={o.id} className={`border-t ${o.eligible ? "" : "opacity-60 bg-stone-100"}`}>
                <td className="p-2"><input type="radio" name="sup" disabled={!o.eligible} checked={supplierId === o.id} onChange={() => setSupplierId(o.id)} aria-label={`Select ${o.name}`} /></td>
                <td className="p-2">{o.name}</td><td className="p-2">{inr(o.total_cost)}</td><td className="p-2">{kg(o.kg_co2e)}</td><td className="p-2">{o.lead_time_days} d</td>
                <td className="p-2"><QualityBadge q={o.evidence_quality} /></td>
                <td className="p-2">{o.eligible ? <Badge tone="green">eligible</Badge> : <span className="text-red-700 text-xs">Rejected: {o.reject_reason}</span>}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Card title="Scenario: shift volume to the selected supplier">
        <div className="flex flex-wrap gap-2 mb-4">
          {STEPS.map((s) => <button key={s} onClick={() => setPct(s)} className={`rounded px-3 py-1 text-sm border ${pct === s ? "bg-emerald-800 text-white" : "bg-white"}`}>{s}%</button>)}
        </div>
        {scnErr && <ErrorBox message={scnErr} />}
        {result && (
          <>
            <div className="grid gap-3 sm:grid-cols-3">
              <StatCard label="Total cost" value={inr(result.scenario.cost)} sub={`Baseline ${inr(result.baseline.cost)}`} tone={tone(delta(result.baseline.cost, result.scenario.cost))} />
              <StatCard label="Estimated CO₂e" value={kg(result.scenario.kg_co2e)} sub={`Baseline ${kg(result.baseline.kg_co2e)}`} tone={tone(delta(result.baseline.kg_co2e, result.scenario.kg_co2e))} />
              <StatCard label="Lead time" value={`${result.scenario.lead_time_days} d`} sub={`Baseline ${result.baseline.lead_time_days} d`} tone={tone(delta(result.baseline.lead_time_days, result.scenario.lead_time_days))} />
            </div>
            <p className="text-xs text-stone-500 mt-3">Assumptions: {result.assumptions.join("; ")}</p>
          </>
        )}
      </Card>

      {missing_data?.length > 0 && <Card title="Missing data"><BulletList items={missing_data} /></Card>}
      <Link to={`/approve/${lineId}`} className="inline-block rounded bg-emerald-800 px-4 py-2 text-white">View recommendation</Link>
    </div>
  );
}
