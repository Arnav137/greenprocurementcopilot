import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { uploadFile } from "../api/client.js";
import { ErrorBox, Spinner, Title } from "../components/ui.jsx";

const OK = [".pdf", ".csv", ".xlsx"];
const MAX_MB = 10;

export default function UploadPage() {
  const nav = useNavigate();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const [drag, setDrag] = useState(false);

  async function handle(file) {
    if (!file) return;
    const okType = OK.some((e) => file.name.toLowerCase().endsWith(e));
    if (!okType) return setError(`Unsupported file. Use ${OK.join(", ")}.`);
    if (file.size > MAX_MB * 1024 * 1024) return setError(`File is over ${MAX_MB} MB.`);
    setError(null); setBusy(true);
    try { await uploadFile(file); nav("/review"); }
    catch (e) { setError(e.message); setBusy(false); }
  }

  return (
    <div>
      <Title sub="Invoices (PDF) or purchase exports (CSV/XLSX).">Upload purchasing records</Title>
      {busy ? <Spinner label="Extracting purchase lines. This can take a while with a local model…" /> : (
        <div
          onDragOver={(e) => { e.preventDefault(); setDrag(true); }}
          onDragLeave={() => setDrag(false)}
          onDrop={(e) => { e.preventDefault(); setDrag(false); handle(e.dataTransfer.files[0]); }}
          className={`rounded border-2 border-dashed p-12 text-center ${drag ? "border-emerald-600 bg-emerald-50" : "border-stone-300 bg-white"}`}
        >
          <p className="mb-3">Drag a file here, or</p>
          <input type="file" accept=".pdf,.csv,.xlsx" onChange={(e) => handle(e.target.files[0])} />
          <p className="mt-6 text-sm text-stone-500">No file handy?</p>
          <button onClick={() => nav("/review")} className="mt-1 rounded bg-emerald-800 px-4 py-2 text-white">Use sample data</button>
        </div>
      )}
      {error && <div className="mt-4"><ErrorBox message={error} /></div>}
    </div>
  );
}
