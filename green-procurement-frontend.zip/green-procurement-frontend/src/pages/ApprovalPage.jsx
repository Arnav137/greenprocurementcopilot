import { useState } from "react";
import { useParams } from "react-router-dom";
import { approve, getRecommendation, reportUrl } from "../api/client.js";
import { Badge, BulletList, Card, ErrorBox, Spinner, Title, useAsync } from "../components/ui.jsx";

export default function ApprovalPage() {
  const { lineId } = useParams();
  const { data, loading, error, retry } = useAsync(() => getRecommendation(lineId), [lineId]);
  const [note, setNote] = useState("");
  const [decision, setDecision] = useState(null); // {status, decided_at}
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState(null);

  async function decide(d) {
    setBusy(true); setErr(null);
    try { setDecision(await approve({ line_id: Number(lineId), decision: d, note })); }
    catch (e) { setErr(e.message); }
    finally { setBusy(false); }
  }

  if (loading) return <Spinner label="Preparing recommendation…" />;
  if (error) return <ErrorBox message={error} onRetry={retry} />;

  return (
    <div className="space-y-4">
      <Title sub="Nothing happens until you decide. Your decision is logged.">Recommendation</Title>
      <Card><p className="font-medium">{data.summary}</p></Card>
      <div className="grid gap-4 md:grid-cols-2">
        <Card title="Evidence"><BulletList items={data.evidence} /></Card>
        <Card title="Assumptions"><BulletList items={data.assumptions} /></Card>
        <Card title="Risks"><BulletList items={data.risks} /></Card>
        <Card title="Missing data"><BulletList items={data.missing_data} /></Card>
      </div>
      <Card title="Draft questions for the supplier (not sent)"><BulletList items={data.questions} /></Card>

      {decision ? (
        <Card title="Decision recorded">
          <p className="text-sm mb-3"><Badge tone={decision.status === "approved" ? "green" : "amber"}>{decision.status}</Badge> at {new Date(decision.decided_at).toLocaleString()}</p>
          <a href={reportUrl()} download className="inline-block rounded bg-emerald-800 px-4 py-2 text-white">Download decision brief (PDF)</a>
        </Card>
      ) : (
        <Card title="Your decision">
          <textarea value={note} onChange={(e) => setNote(e.target.value)} placeholder="Optional note" className="w-full rounded border p-2 text-sm mb-3" rows={2} />
          {err && <div className="mb-3"><ErrorBox message={err} /></div>}
          <div className="flex flex-wrap gap-2">
            <button disabled={busy} onClick={() => decide("approved")} className="rounded bg-emerald-800 px-4 py-2 text-white disabled:opacity-50">Approve</button>
            <button disabled={busy} onClick={() => decide("rejected")} className="rounded bg-red-700 px-4 py-2 text-white disabled:opacity-50">Reject</button>
            <button disabled={busy} onClick={() => decide("more_data")} className="rounded border px-4 py-2 disabled:opacity-50">Request more data</button>
          </div>
        </Card>
      )}
    </div>
  );
}
