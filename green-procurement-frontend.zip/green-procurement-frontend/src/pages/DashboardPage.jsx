import { useNavigate } from "react-router-dom";
import { Bar, BarChart, CartesianGrid, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { getHotspots } from "../api/client.js";
import { Badge, Card, ErrorBox, QualityBadge, Spinner, Title, kg, useAsync } from "../components/ui.jsx";

const COLOR = { verified: "#047857", reported: "#0284c7", estimated: "#d97706", unknown: "#a8a29e" };

export default function DashboardPage() {
  const nav = useNavigate();
  const { data, loading, error, retry } = useAsync(getHotspots);
  if (loading) return <Spinner label="Calculating hotspots…" />;
  if (error) return <ErrorBox message={error} onRetry={retry} />;
  const rows = [...data].sort((a, b) => (b.kg_co2e ?? -1) - (a.kg_co2e ?? -1));
  const chart = rows.filter((r) => r.kg_co2e != null);

  return (
    <div className="space-y-4">
      <Title sub="Estimated emissions by purchase. Click a bar to compare suppliers.">Emission hotspots</Title>
      <Card title="Estimated kg CO₂e (bar colour = data quality)">
        <div className="h-72">
          <ResponsiveContainer>
            <BarChart data={chart}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="item" tick={{ fontSize: 12 }} />
              <YAxis />
              <Tooltip formatter={(v) => kg(v)} />
              <Bar dataKey="kg_co2e" cursor="pointer" onClick={(d) => nav(`/compare/${d.line_id}`)}>
                {chart.map((r) => <Cell key={r.line_id} fill={COLOR[r.quality] || COLOR.unknown} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>
      <div className="overflow-x-auto rounded border bg-white">
        <table className="w-full text-sm">
          <thead className="bg-stone-100 text-left"><tr>{["Purchase", "Estimate", "Method", "Quality", "Factor source"].map((h) => <th key={h} className="p-2 font-medium">{h}</th>)}</tr></thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.line_id} className="border-t hover:bg-stone-50 cursor-pointer" onClick={() => nav(`/compare/${r.line_id}`)}>
                <td className="p-2">{r.item}</td>
                <td className="p-2">{r.kg_co2e == null ? <Badge tone="red">Unavailable: needs data</Badge> : kg(r.kg_co2e)}</td>
                <td className="p-2">{r.method ? <Badge>{r.method}</Badge> : "-"}</td>
                <td className="p-2"><QualityBadge q={r.quality} /></td>
                <td className="p-2 text-xs text-stone-500">{r.factor_source}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
