import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { getLines, patchLine } from "../api/client.js";
import { Badge, Empty, ErrorBox, Spinner, Title, useAsync } from "../components/ui.jsx";

const EDITABLE = ["supplier", "item", "quantity", "unit", "unit_price", "category"];

export default function ReviewPage() {
  const { data, loading, error, retry } = useAsync(getLines);
  const [rows, setRows] = useState([]);
  const [saveErr, setSaveErr] = useState(null);
  useEffect(() => { if (data) setRows(data); }, [data]);

  async function save(id, field, raw) {
    const old = rows.find((r) => r.id === id);
    const value = ["quantity", "unit_price"].includes(field) ? Number(raw) : raw;
    if (old[field] === value) return;
    setRows((rs) => rs.map((r) => r.id === id ? { ...r, [field]: value, uncertain_fields: r.uncertain_fields.filter((f) => f !== field) } : r)); // optimistic
    try { await patchLine(id, { [field]: value }); setSaveErr(null); }
    catch (e) { setRows((rs) => rs.map((r) => (r.id === id ? old : r))); setSaveErr(`Could not save: ${e.message}. Change reverted.`); }
  }

  if (loading) return <Spinner />;
  if (error) return <ErrorBox message={error} onRetry={retry} />;
  if (!rows.length) return <Empty>No lines yet. <Link className="underline" to="/upload">Upload a file</Link>.</Empty>;

  return (
    <div>
      <Title sub="Amber cells were flagged as uncertain. Check them and correct if needed.">Review extracted lines</Title>
      {saveErr && <div className="mb-3"><ErrorBox message={saveErr} /></div>}
      <div className="overflow-x-auto rounded border bg-white">
        <table className="w-full text-sm">
          <thead className="bg-stone-100 text-left"><tr>
            {EDITABLE.map((f) => <th key={f} className="p-2 font-medium">{f.replace("_", " ")}</th>)}
            <th className="p-2 font-medium">confidence</th><th className="p-2 font-medium">source</th>
          </tr></thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id} className="border-t">
                {EDITABLE.map((f) => {
                  const flagged = r.uncertain_fields.includes(f);
                  return (
                    <td key={f} className={`p-1 ${flagged ? "bg-amber-100" : ""}`} title={flagged ? "Uncertain extraction. Please verify." : ""}>
                      <input defaultValue={r[f]} onBlur={(e) => save(r.id, f, e.target.value)} className="w-full bg-transparent p-1 rounded focus:outline-none focus:ring-2 focus:ring-emerald-500" />
                    </td>
                  );
                })}
                <td className="p-2"><Badge tone={r.confidence >= 0.85 ? "green" : r.confidence >= 0.6 ? "amber" : "red"}>{Math.round(r.confidence * 100)}%</Badge></td>
                <td className="p-2 text-xs text-stone-500">{r.source}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <Link to="/dashboard" className="inline-block mt-4 rounded bg-emerald-800 px-4 py-2 text-white">Confirm and calculate emissions</Link>
    </div>
  );
}
